import React from "react";
import styles from "../assets/style/Footer.module.css"
const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <div className={styles.footer}>
      <p>
        Teacher Management System (P) Ltd. &copy; {year} All
        rights reserved.
      </p>
    </div>
  );
};

export default Footer;
