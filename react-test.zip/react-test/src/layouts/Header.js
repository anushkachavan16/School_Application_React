import React from "react";
import logo from "../assets/images/logo.png";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import styles from "../assets/style/Header.module.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faRightFromBracket } from "@fortawesome/free-solid-svg-icons";
import { useState } from "react";
import ModalComponent from "../components/ModalComponent";

const Header = () => {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);

  //method to handle logout
  const handleLogout = () => {
    sessionStorage.removeItem("id");
    sessionStorage.setItem("isLoggedIn", false);
    setShowModal(false);
    navigate("/");
    toast.success("Logged out successfully!");
  };

  // Method to show modal
  const handleShowModal = () => {
    setShowModal(true);
  };

  // Method to close modal
  const handleCloseModal = () => {
    setShowModal(false);
  };

  let login = sessionStorage.getItem("isLoggedIn");

  //static content
  return (
    <div className={styles.header}>
      <img className={styles.logo} alt="logo" src={logo} />
      <ul className={styles.navMenu}>
        <li className={styles.navItem}>
          <a href="/Dashboard">Teacher Management System</a>
        </li>
      </ul>
      {login === "true" && (
        <div className="d-flex align-items-center">
          <span className={styles.textLight}>Welcome, Admin</span>
          <button className={styles.btnOutlineLight} onClick={handleShowModal}>
            Logout
            <FontAwesomeIcon icon={faRightFromBracket} />
          </button>
        </div>
      )}
      <Toaster />
      {showModal && (
        <ModalComponent
          show={showModal}
          handleClose={handleCloseModal}
          handleAction={() => handleLogout()}
          actionName={"Logout"}
        />
      )}
    </div>
  );
};

export default Header;
