import styles from "../assets/style/ErrorPage.module.css"

const ErrorPage = () => {
  return (
    <div className={styles.errorpage}>
      <p className={styles.error}>404 page not found</p>
    </div>
  );
};
export default ErrorPage;
