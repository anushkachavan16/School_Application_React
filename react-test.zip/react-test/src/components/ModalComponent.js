import React from "react";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

const ModalComponent = ({ show, handleClose, handleAction, actionName }) => {
  return (
    <Modal show={show} onHide={handleClose} backdrop="static" keyboard={false}>
      <Modal.Header closeButton>
        <Modal.Title>
          {actionName === "Logout" ? "Logout Confirmation" : "Delete Confirmation"}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {actionName === "Logout"
          ? "Are you sure you want to logout?"
          : "Are you sure you want to delete this user?"}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="danger" onClick={handleAction}>
          {actionName}
        </Button>
        <Button variant="secondary" onClick={handleClose}>
          Cancel
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ModalComponent;
