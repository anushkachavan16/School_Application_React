import React, { useEffect, useState } from "react";
import { Button, Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import ModalComponent from "./ModalComponent";
import { getAllTeachers,deleteTeacher } from "../services/api-service";
import toast from "react-hot-toast";
import styles from "../assets/style/Dashboard.module.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {faPenToSquare,faUserMinus,faPlus} from "@fortawesome/free-solid-svg-icons"

const Dashboard = () => {
  const [showModal, setShowModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [responseData, setResponseData] = useState();

  //intialise data
  useEffect(() => {
    document.title="Dashboard";
    getAllTeachers()
      .then((response) => {
        setResponseData(response.data);
      })
      .catch((error) => {
        toast.error(error);
      });
  }, []);

  // Method to show modal
  const handleShowModal = (id) => {
    setSelectedItem(id);
    setShowModal(true);
  };

  // Method to close modal
  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedItem(null);
  };

  // Handle delete method
  const handleDelete = (id) => {
    setShowModal(false);
    deleteTeacher(id)
      .then(() => {
        setResponseData(responseData.filter((teacher) => teacher.id !== id));
        toast.success("Record deleted successfully");
      })
      .catch(() => {
        toast.error("Error deleting teacher");
      });
  };

  return (
    <>
      <div className={`container ${styles.dashboardContainer}`}>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h2 className={styles.dashboardTitle}>List of Teachers</h2>
          <Button variant="primary" className={styles.addButton}>
            <Link to="/add-teacher" className="text-light text-decoration-none">
              Add Teacher <FontAwesomeIcon icon={faPlus} />
            </Link>
          </Button>
        </div>
        <div className={styles.tableContainer}>
          <Table striped bordered hover className={styles.table}>
            <thead>
              <tr>
                <th>Sr. No.</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Degree</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {responseData &&
                responseData.map((teacher, index) => (
                  <tr key={teacher.id}>
                    <td>{index + 1}</td>
                    <td className={styles.name}>{teacher.firstName}</td>
                    <td className={styles.name}>{teacher.lastName}</td>
                    <td>{teacher.mobile}</td>
                    <td>{teacher.email}</td>
                    <td className={styles.name}>{teacher.gender}</td>
                    <td>{teacher.degree}</td>
                    <td className={styles.actionButtons}>
                      <Link
                        to={`/edit-teacher/${teacher.id}`}
                        className={`btn btn-primary m-2 ${styles.editButton}`}
                      >
                        Edit
                        <FontAwesomeIcon icon={faPenToSquare} />
                      </Link>
                      <Button
                        variant="danger"
                        onClick={() => handleShowModal(teacher.id)}                        
                        className={`btn btn-primary m-2 ${styles.deleteButton}`}
                      >
                        Delete
                        <FontAwesomeIcon icon={faUserMinus} />
                      </Button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>
        </div>
      </div>
      {selectedItem && (
        <ModalComponent
          show={showModal}
          handleClose={handleCloseModal}
          handleAction={() => handleDelete(selectedItem)}
          item={selectedItem}
          actionName={"Delete"}
        />
      )}
    </>
  );
};

export default Dashboard;
