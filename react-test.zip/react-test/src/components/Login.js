import { Formik, Form, Field, ErrorMessage } from "formik";
import { Button } from "react-bootstrap";
import toast, { Toaster } from "react-hot-toast";
import { object, string } from "yup";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import styles from "../assets/style/login.module.css";
import { getAllUsers } from "../services/api-service";

const Login = () => {
  const navigate = useNavigate();

  //initial values
  const initialValuesArray = {
    email: "",
    password: "",
  };

  const [postData, setPostData] = useState(initialValuesArray);

  //validation schema
  const validationSchema = object({
    email: string().required("Email is a required field."),
    password: string().required("Password is a required field."),
  });

  useEffect(() => {
    document.title = "Login";
  });

  //method to handle input change
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setPostData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  //method to handle submit
  const handleSubmit = (values) => {
    getAllUsers()
      .then((response) => {
        const users = response.data;
        const user = users.find((user) => user.email === values.email);
        if (user) {
          if (user.password === values.password) {
            sessionStorage.setItem("isLoggedIn", true);
            sessionStorage.setItem("id", user.id);
            toast.success("Logged In Successfully!");
            navigate("/dashboard");
          } else {
            console.log("why");
            toast.error("Incorrect password");
          }
        } else {
          toast.error("No such email found.");
        }
      })
      .catch(() => {
        toast.error("Error occurred. Please try again later.");
      });
  };

  return (
    <div className={styles.background}>
      <div className={styles.container}>
        <Formik
          initialValues={postData}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
          enableReinitialize
        >
          <Form className={styles.formContainer}>
            <h2>Login</h2>
            <hr></hr>
            <div className={styles.formControl}>
              <label htmlFor="email" className={styles.formLabel}>
                Email
              </label>
              <Field
                className={styles.formField}
                type="text"
                id="email"
                name="email"
                placeholder="Enter email"
                onChange={handleInputChange}
              />
              <ErrorMessage
                name="email"
                component="div"
                className={styles.errorMessage}
              />
            </div>
            <div className={styles.formControl}>
              <label htmlFor="password" className={styles.formLabel}>
                Password
              </label>
              <Field
                className={styles.formField}
                type="password"
                id="password"
                name="password"
                placeholder="Enter password"
                onChange={handleInputChange}
              />
              <ErrorMessage
                name="password"
                component="div"
                className={styles.errorMessage}
              />
            </div>
            <Button type="submit" className={styles.submitButton}>
              Login
            </Button>
          </Form>
        </Formik>
      </div>
      <Toaster />
    </div>
  );
};

export default Login;
