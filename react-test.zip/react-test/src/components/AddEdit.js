import React, { useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import { ErrorMessage, Field, Form, Formik } from "formik";
import { Link, useNavigate, useParams } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import { string, array, object } from "yup";
import styles from "../assets/style/AddEdite.module.css";
import {
  getTeacherById,
  getAllTeachers,
  getDegrees,
  updateTeacher,
  addTeacher,
} from "../services/api-service";

const AddEdit = () => {
  //get id from url
  const { id } = useParams();
  const navigate = useNavigate();

  //initial values
  const initialValues = {
    firstName: "",
    lastName: "",
    email: "",
    mobile: "",
    gender: "",
    address: "",
    degree: "",
    topics: [],
  };

  // Validation function to check if email already exists
  const validateEmailExists = async (email) => {
    try {
      const teachers = await getAllTeachers();
      const emailExists = teachers.data.some(
        (teacher) => teacher.email === email && teacher.id != id
      );
      return !emailExists;
    } catch (error) {
      console.error("Error checking email existence:", error);
      return false;
    }
  };

  //validation schema
  const validationSchema = object({
    firstName: string()
      .required("first name is a required field")
      .min(3)
      .max(20)
      .matches(/^([a-zA-Z]+\s?)*$/, "please enter valid name"),
    lastName: string()
      .required("last name is a required field")
      .min(3)
      .max(30)
      .matches(/^([a-zA-Z]+\s?)*$/, "please enter valid name"),
    email: string()
      .required()
      .matches(/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/, "Enter a valid email")
      .test(
        "email-exists",
        "Email already exists. Please use a different email.",
        validateEmailExists
      ),
    gender: string().required(),
    address: string()
      .required()
      .min(10)
      .max(200)
      .matches(/^([a-zA-Z0-9.,]+\s?)*$/, "please enter valid address"),
    degree: string().required(),
    topics: array().min(1, "Select at least one hobby").required(),
    mobile: string()
      .required()
      .matches(/^(\+\d{1,3}[- ]?)?\d{10}$/, "Please enter valid mobile number"),
  });

  const [postData, setPostData] = useState(initialValues);
  const [degreeOptions, setDegreeOptions] = useState([]);

  //get initial state data
  useEffect(() => {
    
    document.title = "Teacher Form";
    if (id) {
      getTeacherById(id).then((response) => {
        setPostData(response.data);
      });
    }

    getDegrees()
      .then((response) => {
        setDegreeOptions(response.data);
      })
      .catch((error) => {
        toast.error("Error fetching degree options:", error);
      });
  }, [id]);

  //method to handle submit
  const handleSubmit = (values) => {
    const apiCall = id ? updateTeacher(id, values) : addTeacher(values);
    apiCall
      .then(() => {
        let message = id
          ? "Data updated successfully"
          : "Data added successfully";
        navigate("/dashboard");
        toast.success(message);
      })
      .catch(() => {
        toast.error("Error saving post");
      });
  };

  //static content
  return (
    <>
      <div className={`container ${styles.formContainer}`}>
        <h1 className={styles.heading}>
          {id ? "Edit Teacher" : "Add Teacher"}
        </h1>
        <Formik
          initialValues={postData}
          onSubmit={handleSubmit}
          validationSchema={validationSchema}
          enableReinitialize
        >
          {() => (
            <Form>
              <div className="form-group row mb-3">
                <label
                  htmlFor="firstName"
                  className={`col-sm-2 col-form-label ${styles.label}`}
                >
                  First Name:
                </label>
                <div className="col-sm-10">
                  <Field
                    type="text"
                    id="firstName"
                    name="firstName"
                    className="form-control"
                    placeholder="Enter first name"
                  />
                  <ErrorMessage
                    name="firstName"
                    component="div"
                    className="text-danger"
                  />
                </div>
              </div>
              <div className="form-group row mb-3">
                <label
                  htmlFor="lastName"
                  className={`col-sm-2 col-form-label ${styles.label}`}
                >
                  Last Name:
                </label>
                <div className="col-sm-10">
                  <Field
                    type="text"
                    id="lastName"
                    name="lastName"
                    className="form-control"
                    placeholder="Enter last name"
                  />
                  <ErrorMessage
                    name="lastName"
                    component="div"
                    className="text-danger"
                  />
                </div>
              </div>
              <div className="form-group row mb-3">
                <label
                  htmlFor="email"
                  className={`col-sm-2 col-form-label ${styles.label}`}
                >
                  Email:
                </label>
                <div className="col-sm-10">
                  <Field
                    type="text"
                    id="email"
                    name="email"
                    className="form-control"
                    placeholder="Enter email"
                  />
                  <ErrorMessage
                    name="email"
                    component="div"
                    className="text-danger"
                  />
                </div>
              </div>
              <div className="form-group row mb-3">
                <label
                  htmlFor="mobile"
                  className={`col-sm-2 col-form-label ${styles.label}`}
                >
                  Mobile Number:
                </label>
                <div className="col-sm-10">
                  <Field
                    type="text"
                    id="mobile"
                    name="mobile"
                    className="form-control"
                    placeholder="Enter mobile number"
                  />
                  <ErrorMessage
                    name="mobile"
                    component="div"
                    className="text-danger"
                  />
                </div>
              </div>
              <div className="form-group row mb-3">
                <label
                  htmlFor="address"
                  className={`col-sm-2 col-form-label ${styles.label}`}
                >
                  Address:
                </label>
                <div className="col-sm-10">
                  <Field
                    as="textarea"
                    id="address"
                    name="address"
                    className="form-control"
                    placeholder="Enter address"
                  />
                  <ErrorMessage
                    name="address"
                    component="div"
                    className="text-danger"
                  />
                </div>
              </div>
              <fieldset className="form-group mb-3">
                <div className="row">
                  <legend className={`col-sm-2 col-form-label ${styles.label}`}>
                    Gender:
                  </legend>
                  <div className="col-sm-10">
                    <div className="form-check">
                      <Field
                        className="form-check-input"
                        type="radio"
                        name="gender"
                        id="male"
                        value="male"
                      />
                      <label
                        className={`form-check-label${styles.radioBtn}`}
                        htmlFor="male"
                      >
                        Male
                      </label>
                    </div>
                    <div className="form-check">
                      <Field
                        className="form-check-input"
                        type="radio"
                        name="gender"
                        id="female"
                        value="female"
                      />
                      <label className="form-check-label" htmlFor="female">
                        Female
                      </label>
                    </div>
                    <ErrorMessage
                      name="gender"
                      component="div"
                      className="text-danger"
                    />
                  </div>
                </div>
              </fieldset>
              <div className="form-group row mb-3">
                <div className={`col-sm-2 col-form-label ${styles.label}`}>
                  Degree:
                </div>
                <div className="col-sm-10">
                  <Field as="select" name="degree" className="form-control">
                    <option value="">Select Degree</option>
                    {degreeOptions.map((degree, index) => (
                      <option key={index} value={degree}>
                        {degree}
                      </option>
                    ))}
                  </Field>
                  <ErrorMessage
                    name="degree"
                    component="div"
                    className="text-danger"
                  />
                </div>
              </div>
              <fieldset className="form-group mb-3">
                <div className="row">
                  <div className={`col-sm-2 col-form-label ${styles.label}`}>
                    Topics Taught:
                  </div>
                  <div className="col-sm-10">
                    <div className="form-check">
                      <Field
                        className="form-check-input"
                        type="checkbox"
                        id="maths"
                        name="topics"
                        value="maths"
                      />
                      <label className="form-check-label" htmlFor="maths">
                        Maths
                      </label>
                    </div>
                    <div className="form-check">
                      <Field
                        className="form-check-input"
                        type="checkbox"
                        id="science"
                        name="topics"
                        value="science"
                      />
                      <label className="form-check-label" htmlFor="science">
                        Science
                      </label>
                    </div>
                    <div className="form-check">
                      <Field
                        className="form-check-input"
                        type="checkbox"
                        id="history"
                        name="topics"
                        value="history"
                      />
                      <label className="form-check-label" htmlFor="history">
                        History
                      </label>
                    </div>
                    <div className="form-check">
                      <Field
                        className="form-check-input"
                        type="checkbox"
                        id="geography"
                        name="topics"
                        value="geography"
                      />
                      <label className="form-check-label" htmlFor="geography">
                        Geography
                      </label>
                    </div>
                    <ErrorMessage
                      name="topics"
                      component="div"
                      className="text-danger"
                    />
                  </div>
                </div>
              </fieldset>
              <div className="form-group row mb-3">
                <div className={`col-sm-10${styles.buttons}`}>
                  <Button type="submit" className="btn btn-primary me-2">
                    Save
                  </Button>
                  <Button type="reset" className="btn btn-secondary me-2">
                    Reset
                  </Button>
                  <Link to="/Dashboard" className="btn btn-dark">
                    Back
                  </Link>
                </div>
              </div>
            </Form>
          )}
        </Formik>
      </div>
      <Toaster />
    </>
  );
};

export default AddEdit;
