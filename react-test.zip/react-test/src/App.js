import "./App.css";
import Header from "./layouts/Header";
import Footer from "./layouts/Footer";
import Login from "./components/Login";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import Dashboard from "./components/Dashboard";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import AddEdit from "./components/AddEdit";
import AuthGuard from "./services/AuthGuard";
import ErrorPage from "./components/ErrorPage";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route
            path="/dashboard"
            element={<AuthGuard Component={Dashboard} />}
          />
          <Route
            path="/add-teacher"
            element={<AuthGuard Component={AddEdit} />}
          />
          <Route
            path="/edit-teacher/:id"
            element={<AuthGuard Component={AddEdit} />}
          />
          <Route path="*" element={<ErrorPage />} />
        </Routes>
      </BrowserRouter>
      <Footer />
    </div>
  );
}

export default App;
