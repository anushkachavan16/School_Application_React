import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import toast,{Toaster} from "react-hot-toast";

const AuthGuard = (props) => {
  const { Component } = props;
  const navigate = useNavigate();

  // if not logged in redirect to login page
  useEffect(() => {
    let login = sessionStorage.getItem("isLoggedIn");
    if (login !== "true") {
      setTimeout(() => {
        toast.error("Unauthorized access");
      }, 50);
      navigate("/");
    }
  });

  return (
    <>
      <Component />
      <Toaster/>
    </>
  );
};

export default AuthGuard;
