import axios from "axios";

// JSON-server url
const apiUrl = "http://localhost:3000";

// Creating instance of api url
const axiosInstance = axios.create({
  baseURL: apiUrl,
});

//get all users
  export const getAllUsers=()=> {
    return axiosInstance.get("/users");
  }

  //get all teachers
  export const getAllTeachers=()=>{
    return axiosInstance.get("/teachers");
  }

  //get teacher by id
  export const getTeacherById=(id)=> {
    return axiosInstance.get("/teachers/"+id);
  }

  //delete teacher
  export const deleteTeacher=(id)=> {
    return axiosInstance.delete("/teachers/"+id);
  }

  //get degrees
  export const getDegrees=()=>{
    return axiosInstance.get("/degree");
  }

  //add teacher
  export const addTeacher=(values)=>{
    return axiosInstance.post("/teachers/", values);
  }

  //update teacher
  export const updateTeacher=(id,values)=>{
    return axiosInstance.put(`/teachers/${id}`, values);
  }
