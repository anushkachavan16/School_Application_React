import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NewsModule } from './modules/news/news.module';
import { RouterModule, Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { CategoryService } from './shared/services/category.service';
import { LoginModule } from './modules/login/login.module';
import { JwtModule } from '@auth0/angular-jwt';
import { CommonModule, DatePipe } from '@angular/common';
import { LoginComponent } from './modules/login/login.component';
import { ErrorPageComponent } from './modules/layouts/error-page/error-page.component';
import { BrowserModule } from '@angular/platform-browser';

const routes: Routes = [
  { path: '', component: LoginComponent },
  {
    path: 'layout',
    loadChildren: () =>
      import('./modules/layouts/layouts.module').then((m) => m.LayoutsModule),
  },
  { path: '**', component: ErrorPageComponent },
];

export function tokenGetter() {
  return localStorage.getItem('accessToken');
}

@NgModule({
  declarations: [AppComponent],
  imports: [
    AppRoutingModule,
    SharedModule,
    BrowserModule,
    CommonModule,
    NgbModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      positionClass: 'toast-top-right',
    }),
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains: ['localhost:7200'],
        disallowedRoutes: [],
      },
    }),
  ],
  providers: [CategoryService, DatePipe],
  bootstrap: [AppComponent],
})
export class AppModule {}
