import { NgModule } from '@angular/core';
import { NewsListComponent } from './news-list/news-list.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { AddEditNewsComponent } from './add-edit-news/add-edit-news.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { LayoutsModule } from '../layouts/layouts.module';
import { CommonModule } from '@angular/common';

const routes: Routes = [];

@NgModule({
  declarations: [NewsListComponent, AddEditNewsComponent],
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    LayoutsModule,
  ],
  exports: [NewsListComponent],
})
export class NewsModule {}
