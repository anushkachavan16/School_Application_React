import { Component, ViewChild } from '@angular/core';
import { NewsService } from '../../../shared/services/news.service';
import { Router } from '@angular/router';
import { NewsView } from '../../../shared/models/newsView.model';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationModalComponent } from '../../../shared/confirmation-modal/confirmation-modal.component'; // Adjust the path as needed
import {
  faPenToSquare,
  faNewspaper,
  faTrashCan,
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'news-list',
  templateUrl: './news-list.component.html',
  styleUrls: ['./news-list.component.scss'],
})
export class NewsListComponent {
  public newsList: NewsView[] = [];
  public deleteId!: string;
  public pageTitle: string = 'List of News';
  public faPenToSquare = faPenToSquare;
  public faNewsPaper = faNewspaper;
  public faTrashCan = faTrashCan;
  @ViewChild('confirmationModal')
  public confirmationModal!: ConfirmationModalComponent;

  constructor(
    private readonly newsService: NewsService,
    private readonly router: Router,
    private readonly toastr: ToastrService
  ) {}

  public ngOnInit(): void {
    this.getNewsList();
  }

  // Get all news
  private getNewsList(): void {
    this.newsService.getNewsList().subscribe({
      next: (response) => {
        this.newsList = response;
      },
      error: (err) => {
        console.log('Error fetching news list.', err);
      },
      complete: () => {
        console.log('Fetching news list completed.');
      },
    });
  }

  // Navigate to news form
  public addNews() {
    this.router.navigate(['/layout/add-news']);
  }

  // Navigate to edit news page
  public editNews(id: string) {
    this.router.navigate(['/layout/edit-news', id]);
  }

  // Method to delete news
  public deleteNews(id: string): void {
    this.newsService.deleteNews(id).subscribe({
      next: () => {
        this.toastr.success('News deleted.');
        this.getNewsList();
      },
      error: () => {
        this.toastr.error('Error deleting news');
      },
      complete: () => {
        console.log('Deleting news completed.');
      },
    });
  }

  // Method to confirm deletion
  public confirmDelete(id: string): void {
    this.deleteId = id;
    this.confirmationModal.showModal();
  }
}
