import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NewsService } from '../../../shared/services/news.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NewsModel } from '../../../shared/models/news.model';
import { CategoryService } from '../../../shared/services/category.service';
import { CategoriesModel } from '../../../shared/models/categories.model';
import { futureDateValidator } from '../../../shared/validators/future-date-validator';
import {
  faArrowLeft,
  faNewspaper,
  faPenToSquare,
} from '@fortawesome/free-solid-svg-icons';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'add-edit-news',
  templateUrl: './add-edit-news.component.html',
})
export class AddEditNewsComponent {
  public newsForm: FormGroup;
  public errorMessage!: string;
  public isEdit: boolean = false;
  public newsCategories!: CategoriesModel[];
  public faArrowLeft = faArrowLeft;
  public faNewspaper = faNewspaper;
  public todayDate: string;
  public faPenToSquare = faPenToSquare;

  private id!: string;
  private initialFormValues: any = {};

  constructor(
    private formBuilder: FormBuilder,
    private newsService: NewsService,
    private router: Router,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private categoryService: CategoryService,
    private datePipe: DatePipe
  ) {
    this.newsForm = this.formBuilder.group({
      newsTitle: [
        '',
        [
          Validators.required,
          Validators.pattern('^(?!.* {2})(?!.* $)(?!^[^A-Za-z]*$).{3,30}$'),
          Validators.minLength(3),
          Validators.maxLength(30),
        ],
      ],
      description: [
        '',
        [
          Validators.required,
          Validators.pattern('^(?!.* {2})(?!.* $)(?!^[^A-Za-z]*$).{3,300}$'),
          Validators.minLength(3),
        ],
      ],
      category: ['', [Validators.required]],
      publishDate: ['', [Validators.required, futureDateValidator()]],
      status: ['', [Validators.required]],
    });

    this.todayDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd')!;
  }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.categoryService
      .getCategories()
      .subscribe((categories: CategoriesModel[]) => {
        this.newsCategories = categories;
      });

    if (this.id) {
      this.isEdit = true;
      this.newsService.getNewsById(this.id).subscribe({
        next: (response) => {
          const publishDate = response.publishDate
            ? new Date(response.publishDate)
            : '';
          const formattedPublishDate = publishDate
            ? this.datePipe.transform(publishDate, 'yyyy-MM-dd')
            : '';

          this.newsForm.patchValue({
            newsTitle: response.title,
            description: response.description,
            category: response.category,
            status: response.status,
            publishDate: formattedPublishDate,
          });

          this.initialFormValues = this.newsForm.getRawValue();
        },
        error: () => {
          this.toastr.error('Error fetching news details');
        },
        complete: () => {
          console.log('Fetching news details complete');
        },
      });
    } else {
      this.initialFormValues = this.newsForm.getRawValue();
    }
  }

  //submit the form
  public onSubmit(): void {
    if (this.newsForm.invalid) {
      this.toastr.error('Form is invalid.');
      return;
    }

    const news: NewsModel = {
      title: this.newsForm.value.newsTitle,
      description: this.newsForm.value.description,
      status: this.newsForm.value.status,
      category: this.newsForm.value.category,
      publishDate: this.newsForm.value.publishDate,
    };

    if (this.isEdit) {
      this.newsService.updateNews(news, this.id).subscribe({
        next: () => {
          this.toastr.success('News updated');
          this.router.navigate(['/layout/news-list']);
        },
        error: () => {
          this.toastr.error('Error updating news');
        },
        complete: () => {
          console.log('Updating news complete');
        },
      });
    } else {
      this.newsService.addNews(news).subscribe({
        next: () => {
          this.toastr.success('News added.');
          this.router.navigate(['/layout/news-list']);
        },
        error: () => {
          this.toastr.error('Error adding news');
        },
        complete: () => {
          console.log('Adding news complete');
        },
      });
    }
  }

  //reset the form
  public onReset(): void {
    if (this.isEdit) {
      this.newsForm.patchValue(this.initialFormValues);
    } else {
      this.newsForm.reset();
    }
  }
}
