import { NgModule } from '@angular/core';
import { LoginComponent } from './login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [LoginComponent],
  imports: [FormsModule, CommonModule, BrowserModule, ReactiveFormsModule],
  exports: [LoginComponent],
})
export class LoginModule {}
