import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginService } from '../../shared/services/login.service';
import { Login } from '../../shared/models/login.model';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent implements OnInit {
  public invalidLogin!: boolean;
  public loginForm: FormGroup;

  constructor(
    private readonly router: Router,
    private readonly toastr: ToastrService,
    private formbuilder: FormBuilder,
    private readonly loginService: LoginService
  ) {
    this.loginForm = this.formbuilder.group({
      email: [
        '',
        [Validators.required, Validators.minLength(3), Validators.email],
      ],
      password: ['', Validators.required],
    });
  }

  //clear user data in local storage
  public ngOnInit() {
    localStorage.clear();
  }

  //submit the data for login
  public onSubmit() {
    if (this.loginForm.invalid) {
      this.toastr.error('Invalid form, please fill correct data.');
      return;
    }

    const credentials: Login = {
      email: this.loginForm.value.email,
      password: this.loginForm.value.password,
    };

    this.loginService.login(credentials).subscribe({
      next: (response) => {
        localStorage.setItem('accessToken', response.accessToken);
        localStorage.setItem('refreshToken', response.refreshToken);
        localStorage.setItem('email', this.loginForm.value.email);
        this.invalidLogin = false;
        this.router.navigate(['/layout/news-list']);
        this.toastr.success('Logged in succesfully');
      },
      error: () => {
        this.toastr.error('Invalid credentials.');
        this.invalidLogin = true;
      },
      complete: () => {
        console.log('Login called.');
      },
    });
  }
}
