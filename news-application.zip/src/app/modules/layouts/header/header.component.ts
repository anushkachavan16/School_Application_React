import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { faRightFromBracket } from '@fortawesome/free-solid-svg-icons';
import { AuthGuardService } from '../../../shared/services/auth-guard.service';
import { ConfirmationModalComponent } from '../../../shared/confirmation-modal/confirmation-modal.component';

@Component({
  selector: 'header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  public selectedRoute: string = '';
  public faRightFromBracket = faRightFromBracket;

  @ViewChild('confirmationModal')
  confirmationModal!: ConfirmationModalComponent;

  constructor(
    private readonly router: Router,
    private readonly toastr: ToastrService,
    private readonly authService: AuthGuardService
  ) {}

  // Confirm logout
  public confirmLogout(): void {
    this.confirmationModal.showModal();
  }

  // Logout function
  public logout(): void {
    localStorage.clear();
    this.router.navigate(['']);
    this.toastr.success('Logged out.');
  }

  // Check whether user is logged in
  public isLogin(): boolean {
    return this.authService.isUserAuthenticated();
  }

  // Check if user is logged in and navigate
  public checkLogin(route: string): void {
    if (this.authService.isLogin()) {
      this.selectedRoute = route;
      this.router.navigate([route]);
    }
  }
}
