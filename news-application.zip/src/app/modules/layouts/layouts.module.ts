import { NgModule } from '@angular/core';
import { ErrorPageComponent } from './error-page/error-page.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomepageComponent } from './homepage/homepage.component';
import { RouterModule, Routes } from '@angular/router';
import { ApiRoutes } from '../../shared/constants/api-routes';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SharedModule } from '../../shared/shared.module';
import { CommonModule } from '@angular/common';
import { NewsListComponent } from '../news/news-list/news-list.component';
import { LayoutComponent } from './layout/layout.component';
import { AddEditNewsComponent } from '../news/add-edit-news/add-edit-news.component';
import { AuthGuard } from '../../shared/guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: ApiRoutes.newsList,
        component: NewsListComponent,
        canActivate: [AuthGuard],
      },
      {
        path: ApiRoutes.addNews,
        component: AddEditNewsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: ApiRoutes.editNews,
        component: AddEditNewsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: ApiRoutes.homepage,
        component: HomepageComponent,
      },
      { path: '', redirectTo: ApiRoutes.newsList, pathMatch: 'full' },
    ],
  },
];

@NgModule({
  declarations: [
    ErrorPageComponent,
    HeaderComponent,
    FooterComponent,
    HomepageComponent,
    LayoutComponent,
  ],
  imports: [
    RouterModule.forChild(routes),
    FontAwesomeModule,
    CommonModule,
    SharedModule,
  ],
  exports: [
    ErrorPageComponent,
    HeaderComponent,
    FooterComponent,
    HomepageComponent,
    LayoutComponent,
  ],
  providers: [],
})
export class LayoutsModule {}
