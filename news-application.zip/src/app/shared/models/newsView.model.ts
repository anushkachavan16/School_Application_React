export interface NewsView {
  id: string;
  title: string;
  status: string;
  publishDate: Date;
  description: string;
  category: string;
}
