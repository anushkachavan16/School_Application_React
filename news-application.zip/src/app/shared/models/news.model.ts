export interface NewsModel {
  title: string;
  status: string;
  publishDate: Date;
  description: string;
  category: string;
}
