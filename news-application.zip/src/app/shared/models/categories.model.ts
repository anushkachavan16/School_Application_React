export class CategoriesModel {
  id!: string;
  category!: string;
}
