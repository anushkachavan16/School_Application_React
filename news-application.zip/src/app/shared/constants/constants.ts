export class Constants {
  public static baseUrl = 'https://localhost:7200/api/News';
  public static loginUrl = 'https://localhost:7200/api/Login';
}
