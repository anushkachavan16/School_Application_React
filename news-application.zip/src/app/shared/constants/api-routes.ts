export class ApiRoutes {
  public static newsList = 'news-list';
  public static addNews = 'add-news';
  public static editNews = 'edit-news/:id';
  public static homepage = 'homepage';
  public static login = 'login';
}
