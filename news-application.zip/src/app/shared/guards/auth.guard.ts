import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { LoginService } from '../services/login.service';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private jwtHelper: JwtHelperService,
    private router: Router,
    private loginService: LoginService,
    private toastr: ToastrService
  ) {}

  public canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ) {
    const token = localStorage.getItem('accessToken');
    const refreshToken = localStorage.getItem('refreshToken');
    const payload = {
      accessToken: token,
      refreshToken: refreshToken,
    };

    //check token validity
    if (token) {
      if (!this.jwtHelper.isTokenExpired(token)) {
        return true;
      } else {
        if (this.jwtHelper.isTokenExpired(token)) {
          this.loginService.reLogin(payload).subscribe({
            next: (response) => {
              localStorage.setItem('accessToken', response.accessToken);
              localStorage.setItem('refreshToken', response.refreshToken);
              this.router.navigateByUrl(state.url);
              return true;
            },
            error: () => {
              localStorage.clear();
              this.toastr.error('Session expired, please relogin');
              return false;
            },
            complete: () => {
              console.log('relogin called.');
            },
          });
        }
        this.router.navigate(['']);
        return false;
      }
    } else {
      localStorage.clear();
      this.router.navigate(['']);
      this.toastr.error('Please login to access this page.');
      return false;
    }
  }
}
