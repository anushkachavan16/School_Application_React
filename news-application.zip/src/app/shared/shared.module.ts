import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { AuthGuardService } from './services/auth-guard.service';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ConfirmationModalComponent } from './confirmation-modal/confirmation-modal.component';

const routes: Routes = [];

@NgModule({
  declarations: [ConfirmationModalComponent],
  imports: [
    HttpClientModule,
    RouterModule.forChild(routes),
    CommonModule,
    FontAwesomeModule,
  ],
  exports: [ConfirmationModalComponent],
  providers: [AuthGuard, AuthGuardService],
})
export class SharedModule {}
