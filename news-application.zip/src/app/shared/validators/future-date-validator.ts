import { AbstractControl, ValidatorFn } from '@angular/forms';

// Custom validator function to allow only dates in the future
export function futureDateValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const selectedDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (selectedDate <= today) {
      return { futureDate: true };
    }
    return null;
  };
}
