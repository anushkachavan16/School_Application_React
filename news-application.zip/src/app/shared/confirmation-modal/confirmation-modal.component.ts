import {
  Component,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  ElementRef,
  AfterViewInit,
} from '@angular/core';

@Component({
  selector: 'confirmation-modal',
  templateUrl: './confirmation-modal.component.html',
})
export class ConfirmationModalComponent implements AfterViewInit {
  @Input() type: 'delete' | 'logout' = 'delete';
  @Input() itemId: string = '';
  @Output() confirm = new EventEmitter<void>();
  @ViewChild('modalElement') modalElement!: ElementRef;
  private isVisible: boolean = false;

  ngAfterViewInit(): void {
    this.updateVisibility();
  }

  // Display modal
  showModal(): void {
    this.isVisible = true;
    this.updateVisibility();
  }

  // Hide modal
  hideModal(): void {
    this.isVisible = false;
    this.updateVisibility();
  }

  // Confirm action
  onConfirm(): void {
    this.confirm.emit();
    this.hideModal();
  }

  // Change visibility of modal
  private updateVisibility(): void {
    const body = document.body;
    if (this.isVisible) {
      this.modalElement.nativeElement.style.display = 'block';
      this.modalElement.nativeElement.classList.add('show');
      body.classList.add('modal-open');
    } else {
      this.modalElement.nativeElement.style.display = 'none';
      this.modalElement.nativeElement.classList.remove('show');
      body.classList.remove('modal-open');
      body.classList.remove('blurred');
    }
  }

  // Set Modal title
  getModalTitle(): string {
    return this.type === 'delete'
      ? 'Delete Confirmation'
      : 'Logout Confirmation';
  }

  //Set modal message
  getModalMessage(): string {
    return this.type === 'delete'
      ? 'Are you sure you want to delete this item?'
      : 'Are you sure you want to log out?';
  }
}
