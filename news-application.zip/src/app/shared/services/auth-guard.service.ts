import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class AuthGuardService {
  constructor(
    private readonly jwtHelper: JwtHelperService,
    private readonly router: Router,
    private toastr: ToastrService
  ) {}

  //check if user is valid
  public isUserAuthenticated(): boolean {
    const token = localStorage.getItem('accessToken');
    if (token && !this.jwtHelper.isTokenExpired(token)) {
      return true;
    } else {
      return false;
    }
  }

  //check if user token is logged in
  public isLogin(): boolean {
    const token = localStorage.getItem('accessToken');
    if (token && !this.jwtHelper.isTokenExpired(token)) {
      return true;
    } else {
      console.log('Invalid token format or token is expired');
      this.toastr.error('Please login to access this page');
      this.router.navigate(['']);
      return false;
    }
  }
}
