import { Injectable } from '@angular/core';
import { CategoriesModel } from '../models/categories.model';
import { Observable } from 'rxjs';
import { Constants } from '../constants/constants';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CategoryService {
  constructor(private readonly http: HttpClient) {}

  //get categories from database
  public getCategories(): Observable<CategoriesModel[]> {
    return this.http.get<CategoriesModel[]>(`${Constants.baseUrl}/categories`);
  }
}
