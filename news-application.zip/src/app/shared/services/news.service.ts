import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Constants } from '../constants/constants';
import { NewsModel } from '../models/news.model';
import { NewsView } from '../models/newsView.model';
@Injectable({
  providedIn: 'root',
})
export class NewsService {
  constructor(private readonly http: HttpClient) {}

  //get all news list
  public getNewsList(): Observable<NewsView[]> {
    return this.http.get<NewsView[]>(`${Constants.baseUrl}/all`);
  }

  //add news
  public addNews(news: NewsModel): Observable<Object> {
    return this.http.post(`${Constants.baseUrl}/create`, news);
  }

  //Get by Id
  public getNewsById(id: string): Observable<NewsModel> {
    return this.http.get<NewsModel>(`${Constants.baseUrl}/get?id=${id}`);
  }

  //Update
  public updateNews(news: NewsModel, id: string): Observable<Object> {
    return this.http.put(`${Constants.baseUrl}/update?id=${id}`, news);
  }

  //delete
  public deleteNews(id: string): Observable<Object> {
    return this.http.delete(`${Constants.baseUrl}/delete?id=${id}`);
  }
}
