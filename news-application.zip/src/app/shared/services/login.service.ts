import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Constants } from '../constants/constants';
import { Login } from '../models/login.model';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  constructor(private readonly http: HttpClient) {}

  //login method
  public login(credentials: Login): Observable<any> {
    return this.http.post(Constants.loginUrl + '/login', credentials);
  }

  //refresh token generator
  public reLogin(token: any): Observable<any> {
    return this.http.post(Constants.loginUrl + '/refreshToken', token);
  }
}
