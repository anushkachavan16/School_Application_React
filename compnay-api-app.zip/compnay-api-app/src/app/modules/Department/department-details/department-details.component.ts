import { Component, OnInit } from '@angular/core';
import { DepartmentViewModel } from '../../../models/department-view.model';
import { ActivatedRoute } from '@angular/router';
import { DepartmentService } from '../../../services/department.service';

@Component({
  selector: 'app-department-details',
  templateUrl: './department-details.component.html',
  styleUrl: './department-details.component.css'
})
export class DepartmentDetailsComponent implements OnInit {
  public id: string = ''; // Variable to store the employee ID from the route
  public department: DepartmentViewModel = new DepartmentViewModel(); // Variable to store the employee details

  // Constructor to inject ActivatedRoute and EmployeeService
  constructor(
    private route: ActivatedRoute, 
    private departmentService: DepartmentService
  ) { }

  // ngOnInit lifecycle hook to initialize the component
  public ngOnInit(): void {
    // Retrieve the employee ID from the route parameters
    this.id = this.route.snapshot.params['id'];

    // Fetch the employee details using the EmployeeService
    this.getEmployeeDetails();
  }

  // Method to fetch employee details
  private getEmployeeDetails(): void {
    this.departmentService.getDepartmentById(this.id).subscribe(
      (data: DepartmentViewModel) => {
        this.department = data; // Assign the retrieved data to the employee variable
      },
      (error: any) => {
        console.error('Error fetching employee details:', error); // Log any errors that occur
      }
    );
  }
}
