import { Component, OnInit } from '@angular/core';
import { DepartmentViewModel } from '../../../models/department-view.model';
import { DepartmentService } from '../../../services/department.service';
import { Router } from '@angular/router';
import { ModalServiceService } from '../../../services/modalService.service';

@Component({
  selector: 'app-departments-list',
  templateUrl: './departments-list.component.html',
  styleUrl: './departments-list.component.css',
})
export class DepartmentsListComponent implements OnInit {
  public departments: DepartmentViewModel[] = [];
  public deleteId!: string;

  constructor(
    private departmentService: DepartmentService,
    private router: Router,
    private modalService: ModalServiceService
  ) {}

  public ngOnInit(): void {
    this.getDepartments();
  }

  private getDepartments(): void {
    this.departmentService
      .getDepartmentsList()
      .subscribe((data: DepartmentViewModel[]) => {
        this.departments = data;
      });
  }

  // Method to navigate to the employee details page
  public departmentDetails(id: string): void {
    this.router.navigate(['department-details', id]); // Navigate to the employee details page with the employee ID
  }

  // Method to navigate to the update employee page
  public updateDepartment(id: string): void {
    this.router.navigate(['create-department', id]); // Navigate to the update employee page with the employee ID
  }

  public deleteDepartment(id: string): void {
    this.departmentService.deleteDepartment(id).subscribe((data: any) => {
      this.modalService.closeModal('myDeleteModal');
      alert('Department deleted succesfully');
      this.getDepartments();
    });
  }

  public confirmDelete(id: string): void {
    this.deleteId = id;
    this.modalService.openModal('myDeleteModal');
  }

  closeModal(modalId: string): void {
    this.modalService.closeModal(modalId);
  }
}
