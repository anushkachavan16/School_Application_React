import { Component, OnInit } from '@angular/core';
import { DepartmentModel } from '../../../models/department.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DepartmentService } from '../../../services/department.service';
import { debug } from 'console';
import { DepartmentViewModel } from '../../../models/department-view.model';
import { response } from 'express';

@Component({
  selector: 'app-add-edit-department',
  templateUrl: './add-edit-department.component.html',
  styleUrl: './add-edit-department.component.css',
})
export class CreateDepartmentComponent implements OnInit {
  public departmentForm: FormGroup; // Form group for employee form
  public submitted: boolean = false; // Flag to check if form has been submitted
  private department: DepartmentModel | null = null;
  private departmentId: string = '';
  public isEdit: boolean = false;
  public errorMessage: string = ''; // Error message to display if employee already exists

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private departmentService: DepartmentService,
    private route: ActivatedRoute
  ) {
    // Initialize the employee form with form controls and validators
    this.departmentForm = this.formBuilder.group({
      departmentName: [
        '',
        [Validators.required, Validators.pattern('[a-zA-Z ]*')],
      ],
    });
  }
  ngOnInit(): void {
    this.departmentId = this.route.snapshot.params['id']; // Retrieve employee ID from route parameters

    // Fetch the department details using the department ID
    this.departmentService.getDepartmentById(this.departmentId).subscribe(
      (data: DepartmentViewModel) => {
        this.department = data; // Assign fetched department data to the local 'department' object
        this.departmentForm.patchValue(data); // Populate form with fetched department data
      },
      (error: any) => {
        console.error('Error fetching department details:', error); // Log error if fetching department fails
      }
    );
  }

  // Getter for form controls to access them in the template
  get f(): { [key: string]: any } {
    return this.departmentForm.controls;
  }

  // Submit handler for the form
  public onSubmit(): void {
    // If the form is invalid, return early
    if (this.departmentForm.invalid) {
      debugger;
      alert('invalid');
      return;
    } else {
      debugger;
      this.submitted = true; // Mark the form as submitted     

      const Department: DepartmentModel = {
        departmentName: this.departmentForm.value.departmentName,
      };

      if (this.isEdit) {
        // Update the employee details using the employeeService
        this.departmentService
          .updateDepartment(this.departmentId, Department)
          .subscribe(
            (data) => {
              alert('Department updated successfully');

              this.goToEmployeeList(); // Navigate back to employee list after successful update
            },
            (error) => {
              console.error('Error updating department:', error); // Log error if updating employee fails
            }
          );
      } else {
        this.departmentService
          .createDepartment(Department)
          .subscribe((data) => {
            if(response.statusCode==200){
              alert(response.statusMessage);
            }
            console.log(data); // Check the structure of 'data'
            debugger;
            alert('Department Added Successfully');
          });
      }
    }
  }

  // Navigate to the employee list page
  public goToEmployeeList(): void {
    debugger;
    this.router.navigate(['/departments']);
  }
}
