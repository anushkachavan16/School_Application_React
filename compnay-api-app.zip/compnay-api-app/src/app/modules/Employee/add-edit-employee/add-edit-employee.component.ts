import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Route, Router } from '@angular/router';
import { EmployeeService } from '../../../services/employee.service';
import { EmployeeCreate } from '../../../models/employee-view.model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-edit-employee',
  templateUrl: './add-edit-employee.component.html',
  styleUrls: ['./add-edit-employee.component.css'],
})
export class CreateEmployeeComponent implements OnInit {
  public employeeForm: FormGroup; // Form group for employee form
  public submitted: boolean = false; // Flag to check if form has been submitted
  private employees: EmployeeCreate[] = []; // List of employees
  private employeeId: string = '';
  public errorMessage: string = ''; // Error message to display if employee already exists
  public isEdit: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private employeeService: EmployeeService,
    private toastr: ToastrService
  ) {
    // Initialize the employee form with form controls and validators
    this.employeeForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('[a-zA-Z ]*')]],
      lastName: ['', [Validators.required, Validators.pattern('[a-zA-Z ]*')]],
      email: ['', [Validators.required, Validators.email]],
      gender: ['', [Validators.required]],
      address: ['', [Validators.required]],
      designation: ['', [Validators.required]],
      deptId: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      dateOfJoining: ['', Validators.required],
      isActive: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    // Fetch the list of employees to determine the next employee ID
    this.employeeId = this.route.snapshot.params['id'];
    if (this.employeeId) {
      this.isEdit = true;
      this.employeeService
        .getEmployeeById(this.employeeId)
        .subscribe((result) => {
          console.log(result);
          this.employeeForm.patchValue(result);
        });
    }
  }

  // Getter for form controls to access them in the template
  get f(): { [key: string]: any } {
    return this.employeeForm.controls;
  }

  // Submit handler for the form
  public onSubmit(): void {
    this.submitted = true; // Mark the form as submitted
    console.log('Submit clicked');
    // If the form is invalid, return early
    if (this.employeeForm.invalid) {
      console.log('invalid');
      return;
    }

    // Create a new employee object with form values
    const Employee: EmployeeCreate = {
      firstName: this.employeeForm.value.firstName,
      lastName: this.employeeForm.value.lastName,
      email: this.employeeForm.value.email,
      gender: this.employeeForm.value.gender,
      address: this.employeeForm.value.address,
      designation: this.employeeForm.value.designation,
      deptId: this.employeeForm.value.deptId,
      dateOfJoining: this.employeeForm.value.dateOfJoining,
      dateOfBirth: this.employeeForm.value.dateOfBirth,
      isActive: this.employeeForm.value.isActive,
    };

    // Check if an employee with the same name already exists
    const employeeExists: boolean = this.checkIfEmployeeExists(Employee);

    if (employeeExists) {
      // If employee exists, set an error message and return early
      this.errorMessage =
        'Employee already exists! Please enter a different employee.';
      this.toastr.error(this.errorMessage, 'Error'); // Show error toastr message
      return;
    }

    if (this.isEdit) {
      this.employeeService.updateEmployee(this.employeeId, Employee).subscribe(
        data => {
          debugger;
          this.toastr.success('Employee updated successfully', 'Success');
          debugger;
          this.goToEmployeeList(); // Navigate back to employee list after successful update
        },
        error => {
          console.error('Error updating employee:', error); // Log error if updating employee fails
        }
      );
    } else {
      // Create a new employee
      this.employeeService.createEmployee(Employee).subscribe(() => {
        this.goToEmployeeList(); // Navigate to employee list after creation
        this.toastr.success('Employee added successfully', 'Success'); // Show success toastr message
      });
    }
  }

  // Function to check if an employee with the same name already exists
  private checkIfEmployeeExists(newEmployee: EmployeeCreate): boolean {
    const existingEmployee = this.employees.find(
      (emp) =>
        emp.firstName === newEmployee.firstName &&
        emp.lastName === newEmployee.lastName
    );

    return !!existingEmployee;
  }

  // Navigate to the employee list page
  private goToEmployeeList(): void {
    this.router.navigate(['/employees']);
  }
}
