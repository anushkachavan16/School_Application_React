import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Employee } from '../../../models/employee.model';
import { EmployeeService } from '../../../services/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  // Array to hold the list of employees
  public employees: Employee[] = [];

  // Constructor to inject services
  constructor(
    private employeeService: EmployeeService,
    private router: Router,
    private toastr: ToastrService
  ) { }

  // ngOnInit lifecycle hook, called when the component is initialized
  public ngOnInit(): void {
    this.getEmployees(); // Fetch the list of employees when component initializes
  }

  // Method to fetch the list of employees from the service
  private getEmployees(): void {
    this.employeeService.getEmployeesList().subscribe((data: Employee[]) => {
      this.employees = data;
    });
  }

  // Method to navigate to the employee details page
  public employeeDetails(id: string): void {
    this.router.navigate(['employee-details', id]); // Navigate to the employee details page with the employee ID
  }

  // Method to navigate to the update employee page
  public updateEmployee(id: string): void {
    this.router.navigate(['create-employee', id]); // Navigate to the update employee page with the employee ID
  }

  // Method to delete an employee
  public deleteEmployee(id: string): void {
    this.employeeService.deleteEmployee(id).subscribe((data: any) => {
      this.toastr.success('Deleted', 'Success'); // Show success notification using ToastrService
     this.getEmployees(); // Refresh the list of employees after deletion
    });
  }
}
