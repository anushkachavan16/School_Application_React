import { Component, OnInit } from '@angular/core';
import { Employee } from '../../../models/employee.model';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../../../services/employee.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  public id: string = ''; // Variable to store the employee ID from the route
  public employee: Employee = new Employee(); // Variable to store the employee details

  // Constructor to inject ActivatedRoute and EmployeeService
  constructor(
    private route: ActivatedRoute, 
    private employeeService: EmployeeService
  ) { }

  // ngOnInit lifecycle hook to initialize the component
  public ngOnInit(): void {
    // Retrieve the employee ID from the route parameters
    this.id = this.route.snapshot.params['id'];

    // Fetch the employee details using the EmployeeService
    this.getEmployeeDetails();
  }

  // Method to fetch employee details
  private getEmployeeDetails(): void {
    this.employeeService.getEmployeeById(this.id).subscribe(
      (data: Employee) => {
        this.employee = data; // Assign the retrieved data to the employee variable
      },
      (error: any) => {
        console.error('Error fetching employee details:', error); // Log any errors that occur
      }
    );
  }
}
