import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DepartmentModel } from '../models/department.model';
import { DepartmentViewModel } from '../models/department-view.model';

@Injectable({
  providedIn: 'root', // This service is available application-wide
})
export class DepartmentService {
  private baseUrl = 'https://localhost:7144/api/Company';

  constructor(private readonly httpClient: HttpClient) {}

  // Method to get the list of all employees
  public getDepartmentsList(): Observable<DepartmentViewModel[]> {
    return this.httpClient.get<DepartmentViewModel[]>(
      `${this.baseUrl}/departments/all`
    ); // GET request to fetch all employees
  }

  // Method to get an employee by ID
  public getDepartmentById(id: string): Observable<DepartmentViewModel> {
    debugger;
    return this.httpClient.get<DepartmentViewModel>(
      `${this.baseUrl}/departments/get?id=${id}`
    ); // GET request to fetch employee by ID
  }

  public createDepartment(department: DepartmentModel): Observable<object> {
    debugger;
    return this.httpClient.post<DepartmentModel>(
      `${this.baseUrl}/departments/add`,
      department
    );
  }

  // Method to update an existing employee
  public updateDepartment(
    id: string,
    department: DepartmentModel
  ): Observable<Object> {
    return this.httpClient.put(
      `${this.baseUrl}/departments/edit/?id=${id}`,
      department
    ); // PUT request to update an employee by ID
  }

  // Method to delete an employee by ID
  public deleteDepartment(id: string): Observable<Object> {
    return this.httpClient.delete(`${this.baseUrl}/departments/${id}`); // DELETE request to delete an employee by ID
  }
}
