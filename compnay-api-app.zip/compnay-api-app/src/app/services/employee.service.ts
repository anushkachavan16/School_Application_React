import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../models/employee.model';
import { EmployeeCreate } from '../models/employee-view.model';

@Injectable({
  providedIn: 'root' // This service is available application-wide
})
export class EmployeeService {

  private baseURL = "http://localhost:7144/api/Company"; // Base URL for the employee API

  constructor(private readonly httpClient: HttpClient) { } // Inject HttpClient for making HTTP requests

  // Method to get the list of all employees
  public getEmployeesList(): Observable<Employee[]> {
    return this.httpClient.get<Employee[]>(`http://localhost:7144/api/Company/employees/all`); // GET request to fetch all employees
  }

  // Method to create a new employee
  public createEmployee(employee: EmployeeCreate): Observable<Object> {
    return this.httpClient.post(`${this.baseURL}/employees/add`, employee); // POST request to create a new employee
  }

  // Method to get an employee by ID
  public getEmployeeById(id: string): Observable<Employee> {
    debugger;
    return this.httpClient.get<Employee>(`${this.baseURL}/employees/get?id=${id}`); // GET request to fetch employee by ID
  }

  // Method to update an existing employee
  public updateEmployee(id: string, employee: EmployeeCreate): Observable<Object> {
    return this.httpClient.put(`${this.baseURL}/employees/edit?id=${id}`, employee); // PUT request to update an employee by ID
  }

  // Method to delete an employee by ID
  public deleteEmployee(id: string): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL}/employees/${id}`); // DELETE request to delete an employee by ID
  }

}
