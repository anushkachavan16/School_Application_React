import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ModalServiceService {

  constructor() {}

  // opening and closing of modal based on modal ID
  openModal(modalID: string): void {
    const modalDiv = document.getElementById(modalID);
    if (modalDiv != null) {
      modalDiv.style.display = 'block';
    }
  }
  closeModal(modalID: string): void {
    const modalDiv = document.getElementById(modalID);
    if (modalDiv != null) {
      modalDiv.style.display = 'none';
    }
  }

}