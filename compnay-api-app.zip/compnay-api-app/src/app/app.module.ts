import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppComponent } from './app.component';
import { EmployeeListComponent } from './modules/Employee/employee-list/employee-list.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
//import { UpdateEmployeeComponent } from './Components/Employee/update-employee/update-employee.component';
import { EmployeeDetailsComponent } from './modules/Employee/employee-details/employee-details.component';
import { CreateDepartmentComponent } from './modules/Department/add-edit-department/add-edit-department.component';
import { DepartmentsListComponent } from './modules/Department/departments-list/departments-list.component';
//import { UpdateDepartmentComponent } from './Components/Department/update-department/update-department.component';
import { DepartmentDetailsComponent } from './modules/Department/department-details/department-details.component';
import { CreateEmployeeComponent } from './modules/Employee/add-edit-employee/add-edit-employee.component';
import { EmployeeService } from './services/employee.service';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    //UpdateEmployeeComponent,
    EmployeeDetailsComponent,
    CreateDepartmentComponent,
    DepartmentsListComponent,
    //UpdateDepartmentComponent,
    DepartmentDetailsComponent,
    CreateEmployeeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: 'toast-top-center',
      preventDuplicates: true,
      progressBar: true,
      closeButton: true
    }),
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
