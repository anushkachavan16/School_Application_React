export interface DepartmentModel{
     departmentName: string ;
}