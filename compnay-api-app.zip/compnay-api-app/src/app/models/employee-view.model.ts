export class EmployeeCreate {
    firstName: string = ''; // First name of the employee
    lastName: string = ''; // Last name of the employee
    email: string = ''; // Email ID of the employee
    gender?:string='';
    address?:string='';
    designation?:string='';
    deptId?:string='';
    dateOfBirth?:Date;
    dateOfJoining?:Date;
    isActive?:boolean=true;
  }
  