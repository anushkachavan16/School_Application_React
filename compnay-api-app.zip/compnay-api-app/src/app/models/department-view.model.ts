export class DepartmentViewModel{
    id:string='';
    departmentName: string ='';
}