export class Employee {
  id: string = ''; // Employee ID (assuming it's a string)
  firstName: string = ''; // First name of the employee
  lastName: string = ''; // Last name of the employee
  email: string = ''; // Email ID of the employee
  gender?:string='';
  address?:string='';
  designation?:string='';
  deptId?:string='';
  dateOfBirth?:string='';
  dateOfJoining?:string='';
  isActive?:string='';
}
