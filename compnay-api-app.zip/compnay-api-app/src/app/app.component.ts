import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser'; // Import Title service

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Assignment-06-Vaishnavi-Gosavi';

  newTitle = 'Angular CRUD Operations';

  constructor(private titleService: Title) {
    this.titleService.setTitle(this.newTitle);
  }
}
