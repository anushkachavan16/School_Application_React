import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './modules/Employee/employee-list/employee-list.component';
import { CreateEmployeeComponent } from './modules/Employee/add-edit-employee/add-edit-employee.component';
//import { UpdateEmployeeComponent } from './Components/Employee/update-employee/update-employee.component';
import { EmployeeDetailsComponent } from './modules/Employee/employee-details/employee-details.component';
import { CreateDepartmentComponent } from './modules/Department/add-edit-department/add-edit-department.component';
import { DepartmentsListComponent } from './modules/Department/departments-list/departments-list.component';
//import { UpdateDepartmentComponent } from './Components/Department/update-department/update-department.component';
import { DepartmentDetailsComponent } from './modules/Department/department-details/department-details.component';

const routes: Routes = [
  { path: 'employees', component: EmployeeListComponent },
  { path: 'create-employee', component: CreateEmployeeComponent },
  { path: '', redirectTo: 'employees', pathMatch: 'full' },
  { path: 'create-employee/:id', component: CreateEmployeeComponent },
  { path: 'employee-details/:id', component: EmployeeDetailsComponent },
  { path: 'create-department', component: CreateDepartmentComponent },
  { path: 'departments', component: DepartmentsListComponent },
  { path: 'create-department/:id', component: CreateDepartmentComponent },
  { path: 'department-details/:id', component: DepartmentDetailsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
