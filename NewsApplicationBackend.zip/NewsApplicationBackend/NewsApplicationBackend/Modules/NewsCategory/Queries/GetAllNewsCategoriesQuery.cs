﻿using MediatR;
using NewsApplicationBackend.Interfaces;

namespace NewsApplicationBackend.Modules.NewsCategory.Queries
{
    public class GetAllNewsCategoriesQuery : IRequest<List<Models.NewsCategory>> { }
    public class GetAllNewsCategoriesQueryHandler : IRequestHandler<GetAllNewsCategoriesQuery, List<Models.NewsCategory>>
    {
        private readonly INewsRepository<Models.NewsCategory> _newsRepository;
        public GetAllNewsCategoriesQueryHandler(INewsRepository<Models.NewsCategory> newsRepository)
        {
            _newsRepository = newsRepository;
        }
        public async Task<List<Models.NewsCategory>> Handle(GetAllNewsCategoriesQuery request, CancellationToken cancellationToken)
        {
            return await _newsRepository.GetAllAsync();
        }
    }
}
