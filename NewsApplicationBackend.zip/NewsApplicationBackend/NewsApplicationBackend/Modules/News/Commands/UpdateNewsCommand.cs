﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using NewsApplicationBackend.Interfaces;
using NewsApplicationBackend.Validators;

namespace NewsApplicationBackend.Modules.News.Commands
{
    public class UpdateNewsCommand : NewsCommand
    {
        public Guid Id { get; set; }
    }
    public class UpdateNewsCommandHandler : IRequestHandler<UpdateNewsCommand, bool>
    {
        private readonly INewsRepository<Models.News> _newsRepository;

        public UpdateNewsCommandHandler(INewsRepository<Models.News> newsRepository)
        {
            _newsRepository = newsRepository;
        }

        public async Task<bool> Handle(UpdateNewsCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new NewsValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }
            try
            {
                var newsData = await _newsRepository.Update(news =>
                {
                    news.Title = request.Title;
                    news.Description = request.Description;
                    news.Status = request.Status;
                    news.PublishDate = request.PublishDate;
                    news.Category = request.Category;
                }, request.Id);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }
        }
    }
}
