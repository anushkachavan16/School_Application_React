﻿using MediatR;
using NewsApplicationBackend.Interfaces;

namespace NewsApplicationBackend.Modules.News.Commands
{
    public class DeleteNewsCommand : IRequest<bool>
    {
        public Guid Id { get; set; }
        public DeleteNewsCommand(Guid id)
        {
            this.Id = id;
        }
    }

    public class DeleteNewsCommandHandler : IRequestHandler<DeleteNewsCommand, bool>
    {
        private readonly INewsRepository<Models.News> _newsRepository;
        public DeleteNewsCommandHandler(INewsRepository<Models.News> newsRepository)
        {
            _newsRepository = newsRepository;
        }

        public async Task<bool> Handle(DeleteNewsCommand request, CancellationToken cancellationToken)
        {
            return await _newsRepository.Delete(request.Id);
        }
    }
}
