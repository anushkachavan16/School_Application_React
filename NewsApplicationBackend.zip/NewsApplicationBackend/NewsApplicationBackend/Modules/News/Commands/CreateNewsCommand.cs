﻿using MediatR;
using NewsApplicationBackend.Interfaces;
using NewsApplicationBackend.Validators;
using System.ComponentModel.DataAnnotations;
using ValidationResult = FluentValidation.Results.ValidationResult;

namespace NewsApplicationBackend.Modules.News.Commands
{
    public class CreateNewsCommand : NewsCommand { }

    public class CreateNewsCommandHandler : IRequestHandler<CreateNewsCommand, bool>
    {
        private readonly INewsRepository<Models.News> _newsRepository;

        public CreateNewsCommandHandler(INewsRepository<Models.News> newsRepository)
        {
            _newsRepository = newsRepository;
        }

        public async Task<bool> Handle(CreateNewsCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new NewsValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors.ToString());
            }
            var teacher = new Models.News()
            {
                Title = request.Title,
                Description = request.Description,
                Status = request.Status,
                PublishDate = request.PublishDate,
                Category = request.Category,
            };

            try
            {
                await _newsRepository.Add(teacher);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }
        }
    }
}
