﻿using MediatR;

namespace NewsApplicationBackend.Modules.News.Commands
{
    public class NewsCommand : IRequest<bool>
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public DateTime PublishDate { get; set; }
        public string Status { get; set; }
    }
}
