﻿using MediatR;
using NewsApplicationBackend.Interfaces;

namespace NewsApplicationBackend.Modules.News.Queries
{
    public class GetNewsByIdQuery : IRequest<Models.News>
    {
        public Guid id { get; set; }
        public GetNewsByIdQuery(Guid Id)
        {
            id = Id;
        }
    }
    public class GetNewsByIdQueryHandler : IRequestHandler<GetNewsByIdQuery, Models.News>
    {
        private readonly INewsRepository<Models.News> _newsRepository;
        public GetNewsByIdQueryHandler(INewsRepository<Models.News> newsRepository)
        {
            _newsRepository = newsRepository;
        }
        public async Task<Models.News> Handle(GetNewsByIdQuery request, CancellationToken cancellationToken)
        {
            return await _newsRepository.GetById(request.id);
        }
    }
}
