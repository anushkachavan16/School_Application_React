﻿using MediatR;
using NewsApplicationBackend.Interfaces;

namespace NewsApplicationBackend.Modules.News.Queries
{
    public class GetAllNewsQuery : IRequest<List<Models.News>> { }
    public class GetAllNewsQueryHandler : IRequestHandler<GetAllNewsQuery, List<Models.News>>
    {
        private readonly INewsRepository<Models.News> _newsRepository;
        public GetAllNewsQueryHandler(INewsRepository<Models.News> newsRepository)
        {
            _newsRepository = newsRepository;
        }
        public async Task<List<Models.News>> Handle(GetAllNewsQuery request, CancellationToken cancellationToken)
        {
            return await _newsRepository.GetAllAsync();
        }
    }
}
