﻿using MediatR;
using NewsApplicationBackend.Interfaces;
using NewsApplicationBackend.Models;

namespace SchoolApplicationBackEnd.Modules.Users.Queries
{
    public class GetAllUsersQuery : IRequest<List<User>> { }

    public class GetAllUsersQueryHandler : IRequestHandler<GetAllUsersQuery, List<User>>
    {
        private readonly INewsRepository<User> _newsRepository;
        public GetAllUsersQueryHandler(INewsRepository<User> newsRepository)
        {
            _newsRepository = newsRepository;
        }
        public async Task<List<User>> Handle(GetAllUsersQuery request, CancellationToken cancellationToken)
        {
            return await _newsRepository.GetAllAsync();
        }
    }
}
