﻿using MediatR;
using NewsApplicationBackend.Interfaces;
using NewsApplicationBackend.Models;

namespace NewsApplicationBackend.Modules.Users.Commands
{
    public class UserLoginCommand : IRequest<Token>
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
    public class UserLoginCommandHandler : IRequestHandler<UserLoginCommand, Token>
    {
        private readonly IAuthRepository _authRepository;
        private readonly IUserRepository _userRepository;

        public UserLoginCommandHandler(IUserRepository userRepository, IAuthRepository authRepository)
        {
            _userRepository = userRepository;
            _authRepository = authRepository;
        }

        public async Task<Token> Handle(UserLoginCommand request, CancellationToken cancellationToken)
        {

            var existingUser =  _userRepository.IsValidUser(request.Email, request.Password);

            if (existingUser == null)
            {
                throw new Exception("User not found");
            }

            var accessToken = _authRepository.GenerateAccessToken(existingUser);
            var refreshToken = _authRepository.GenerateRefreshToken();

            existingUser.RefreshToken = refreshToken;
            existingUser.RefreshTokenExpireTime = DateTime.Now.AddMinutes(6);

            await _userRepository.SaveChanges();

            var token = new Token
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken,
            };

            return token;
        }
    }
}
