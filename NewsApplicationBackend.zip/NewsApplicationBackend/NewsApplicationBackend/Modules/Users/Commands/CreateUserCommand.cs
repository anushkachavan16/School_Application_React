﻿using MediatR;
using NewsApplicationBackend.Interfaces;
using NewsApplicationBackend.Models;

namespace SchoolApplicationBackEnd.Modules.Users.Commands
{
    public class CreateUserCommand : UserCommand { }

    public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, bool>
    {
        private readonly INewsRepository<User> _schoolRepository;

        public CreateUserCommandHandler(INewsRepository<User> schoolRepository)
        {
            _schoolRepository = schoolRepository;
        }

        public async Task<bool> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {

            var user = new User()
            {
                Email = request.Email,
                Password = request.Password,
                RefreshToken = request.RefreshToken,
                RefreshTokenExpireTime = request.RefreshTokenExpireTime,
            };

            try
            {
                await _schoolRepository.Add(user);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }
        }
    }


}

