﻿using MediatR;
using NewsApplicationBackend.Interfaces;
using NewsApplicationBackend.Models;
using System.Security.Claims;

namespace SchoolApplicationBackEnd.Modules.Users.Commands
{
    public class GenerateRefreshTokenCommand : IRequest<Token>
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
    }

    public class GenerateRefreshTokenCommandHandler : IRequestHandler<GenerateRefreshTokenCommand, Token>
    {
        private readonly IUserRepository _userRepository;
        private readonly IAuthRepository _authRepository;

        public GenerateRefreshTokenCommandHandler(IUserRepository userRepository, IAuthRepository authRepository)
        {
            _userRepository = userRepository;
            _authRepository = authRepository;
        }
        public async Task<Token> Handle(GenerateRefreshTokenCommand request, CancellationToken cancellationToken)
        {
            var principal = _authRepository.GetPrincipalFromExpiredToken(request.AccessToken);
            var username = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            var existingUser = await _userRepository.ExistingRefreshToken(username, request.RefreshToken);

            if (existingUser == null || existingUser.RefreshToken != request.RefreshToken || existingUser.RefreshTokenExpireTime < DateTime.Now)
            {
                throw new InvalidOperationException("Token Expired");
            }            

            var newRefreshToken = _authRepository.GenerateRefreshToken();

            var newAccessToken = _authRepository.GenerateAccessToken(existingUser);

            existingUser.RefreshToken = newRefreshToken;
            existingUser.RefreshTokenExpireTime = DateTime.Now.AddMinutes(6);

            await _userRepository.SaveChanges();

            var token = new Token
            {
                AccessToken = newAccessToken,
                RefreshToken = newRefreshToken,
            };

            return token;
        }
    }
}
