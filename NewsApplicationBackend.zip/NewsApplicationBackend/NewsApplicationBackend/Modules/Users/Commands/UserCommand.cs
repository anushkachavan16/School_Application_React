﻿using MediatR;

namespace SchoolApplicationBackEnd.Modules.Users.Commands
{
    public class UserCommand :IRequest<bool>
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string RefreshToken { get; set; }
        public DateTime RefreshTokenExpireTime { get; set; }
    }
}
