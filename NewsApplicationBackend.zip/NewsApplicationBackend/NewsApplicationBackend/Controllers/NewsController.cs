﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NewsApplicationBackend.Modules.News.Commands;
using NewsApplicationBackend.Modules.News.Queries;
using NewsApplicationBackend.Modules.NewsCategory.Queries;
using SchoolApplicationBackEnd.Modules.Users.Commands;
using SchoolApplicationBackEnd.Modules.Users.Queries;
using ValidationException = FluentValidation.ValidationException;

namespace NewsApplicationBackend.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class NewsController : ControllerBase
    {
        private readonly ISender _mediatR;

        public NewsController(ISender mediatr)
        {
            _mediatR = mediatr;
        }

        #region Get All News
        /// <summary>
        /// Method to get All records in news table
        /// </summary>
        /// <returns></returns>
        [HttpGet("all")]
        public async Task<IActionResult> GetNews()
        {
            return Ok(await _mediatR.Send(new GetAllNewsQuery()));
        }
        #endregion

        #region Get News By Id
        /// <summary>
        /// Method to get news record by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("get")]
        public async Task<IActionResult> GetNewsById([FromQuery] Guid id)
        {
            return Ok(await _mediatR.Send(new GetNewsByIdQuery(id)));
        }
        #endregion

        #region Create news
        /// <summary>
        /// Create new news record
        /// </summary>
        /// <param name="news"></param>
        /// <returns></returns>
        [HttpPost("create")]
        public async Task<IActionResult> CreateStudent([FromBody] NewsCommand news)
        {
            try
            {
                return Ok(await _mediatR.Send(new CreateNewsCommand()
                {
                    Title = news.Title,
                    Description = news.Description,
                    Status = news.Status,
                    Category = news.Category,
                    PublishDate = news.PublishDate,
                }));
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.Select(e => e.ErrorMessage).ToList());
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the news.");
            }

        }
        #endregion

        #region Update News
        /// <summary>
        /// Update news record
        /// </summary>
        /// <param name="id"></param>
        /// <param name="news"></param>
        /// <returns></returns>
        [HttpPut("update")]
        public async Task<IActionResult> UpdateNews([FromQuery] Guid id, [FromBody] NewsCommand news)
        {
            try
            {
                return Ok(await _mediatR.Send(new UpdateNewsCommand()
                {
                    Title = news.Title,
                    Status= news.Status,
                    Description= news.Description,
                    PublishDate= news.PublishDate,
                    Category= news.Category,
                    Id = id
                }));
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.Select(e => e.ErrorMessage).ToList());
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while updating the news.");
            }
        }
        #endregion

        #region Delete News
        /// <summary>
        /// Delete record
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("delete")]
        public async Task<IActionResult> DeleteStudent([FromQuery] Guid id)
        {
            return Ok(await _mediatR.Send(new DeleteNewsCommand(id)));
        }
        #endregion

        #region Get News Categories
        /// <summary>
        /// Get news categories from category table
        /// </summary>
        /// <returns></returns>
        [HttpGet("categories")]
        public async Task<IActionResult> GetNewsCategories()
        {
            return Ok(await _mediatR.Send(new GetAllNewsCategoriesQuery()));    
        }
        #endregion


        #region User
        #region Get Users
        /// <summary>
        /// Get all user records
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpGet("users")]
        public async Task<IActionResult> GetUsers()
        {
            return Ok(await _mediatR.Send(new GetAllUsersQuery()));
        }
        #endregion

        #region Create User
        /// <summary>
        /// Create new user
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost("users/add")]
        public async Task<IActionResult> CreateUser(UserCommand user)
        {
            return Ok(await _mediatR.Send(new CreateUserCommand()
            {
                Email = user.Email,
                Password = user.Password,
                RefreshToken = user.RefreshToken,
                RefreshTokenExpireTime = user.RefreshTokenExpireTime,
            }));
        }
        #endregion
        #endregion
    }

}
