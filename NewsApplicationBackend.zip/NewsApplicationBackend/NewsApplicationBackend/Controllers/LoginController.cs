﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using NewsApplicationBackend.Modules.Users.Commands;
using SchoolApplicationBackEnd.Modules.Users.Commands;

namespace NewsApplicationBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ISender _mediatr;
        
        public LoginController(ISender mediatr)
        {
            _mediatr = mediatr;
        }
        
        /// <summary>
        /// Login method
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserLoginCommand userLogin)
        {
            return Ok(await _mediatr.Send(userLogin));
        }

        /// <summary>
        /// Generate Refresh Token
        /// </summary>
        /// <param name="generateRefreshTokenCommand"></param>
        /// <returns></returns>
        [HttpPost("refreshToken")]
        public async Task<IActionResult> GenerateRefreshToken(GenerateRefreshTokenCommand generateRefreshTokenCommand)
        {
            return Ok(await _mediatr.Send(generateRefreshTokenCommand));
        }
    }
}
