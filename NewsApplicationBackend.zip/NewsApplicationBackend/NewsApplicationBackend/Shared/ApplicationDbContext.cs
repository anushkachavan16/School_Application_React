﻿using Microsoft.EntityFrameworkCore;
using NewsApplicationBackend.Models;
using NewsApplicationBackend.Repositories.Configuration;

namespace NewsApplicationBackend.Shared
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options): base(options){ }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new NewsCategoryConfiguration());
        }
        public DbSet<Models.User> Users {  get; set; }
        public DbSet<News> News { get; set; }
        public DbSet<NewsCategory> NewsCategories { get; set; }
        
    }
}
