﻿namespace NewsApplicationBackend.Interfaces
{
    public interface INewsRepository<T> where T : class
    {
        public Task<List<T>> GetAllAsync();
        public Task<bool> Add(T entity);
        public Task<T> GetById(Guid id);
        public Task<bool> Update(Action<T> updateAction, Guid id);
        public Task<bool> Delete(Guid id);
    }
}
