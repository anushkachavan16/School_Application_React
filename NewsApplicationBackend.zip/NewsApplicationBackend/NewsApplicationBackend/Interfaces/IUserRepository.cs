﻿using NewsApplicationBackend.Models;

namespace NewsApplicationBackend.Interfaces
{
    public interface IUserRepository
    {
        User IsValidUser(string username, string password);
        Task<User> ExistingRefreshToken(string username, string token);
        Task<bool> SaveChanges();
    }
}
