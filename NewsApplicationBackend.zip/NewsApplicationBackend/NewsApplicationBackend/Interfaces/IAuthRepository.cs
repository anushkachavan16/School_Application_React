﻿using NewsApplicationBackend.Models;
using System.Security.Claims;

namespace NewsApplicationBackend.Interfaces
{
    public interface IAuthRepository
    {
        string GenerateAccessToken(User user);
        string GenerateRefreshToken();
        ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    }
}
