﻿using FluentValidation;
using NewsApplicationBackend.Modules.News.Commands;

namespace NewsApplicationBackend.Validators
{
    public class NewsValidator : AbstractValidator<NewsCommand>
    {
        public NewsValidator()
        {
            RuleFor(s => s.Title)
                .NotEmpty()
                .NotNull()
                .MinimumLength(3)
                .MaximumLength(30);

            RuleFor(s => s.Description)
                .NotEmpty()
                .NotNull()
                .MinimumLength(3)
                .MaximumLength(300);

            RuleFor(s => s.PublishDate)
                .NotEmpty()
                .NotNull();

            RuleFor(s => s.Status)
                .NotEmpty()
                .NotNull();

            RuleFor(s => s.Category)
                .NotEmpty()
                .NotNull();
        }
    }
}
