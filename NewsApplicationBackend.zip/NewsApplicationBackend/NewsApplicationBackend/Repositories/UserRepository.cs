﻿using Microsoft.EntityFrameworkCore;
using NewsApplicationBackend.Interfaces;
using NewsApplicationBackend.Models;
using NewsApplicationBackend.Shared;

namespace NewsApplicationBackend.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public UserRepository( ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }             

        /// <summary>
        /// Check validity of credentials
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public User IsValidUser(string username,string password)
        {
            var currentUser = _dbContext.Users.FirstOrDefault(x => x.Email.ToLower() ==
                 username.ToLower() && x.Password == password);
            if (currentUser != null)
            {
                return currentUser;
            }
            return null;
        }

        /// <summary>
        /// Save changes to database
        /// </summary>
        /// <returns></returns>
        public async  Task<bool> SaveChanges()
        {
            try
            {
                await _dbContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        /// <summary>
        /// Check whether user exists in database
        /// </summary>
        /// <param name="username"></param>
        /// <param name="refreshToken"></param>
        /// <returns></returns>
        public async Task<User> ExistingRefreshToken(string username, string refreshToken)
        {
            var existingUser = await _dbContext.Users.SingleOrDefaultAsync(u => u.Email == username && u.RefreshToken == refreshToken);
            if (existingUser != null)
            {
                return existingUser;
            }
            return null;
        }
    }
}
