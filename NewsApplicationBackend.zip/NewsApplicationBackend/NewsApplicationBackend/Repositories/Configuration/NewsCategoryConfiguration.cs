﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using NewsApplicationBackend.Models;

namespace NewsApplicationBackend.Repositories.Configuration
{
    public class NewsCategoryConfiguration : IEntityTypeConfiguration<NewsCategory>
    {
        /// <summary>
        /// Seed data into category table
        /// </summary>
        /// <param name="builder"></param>
        public void Configure(EntityTypeBuilder<NewsCategory> builder)
        {
            builder.HasData(
                new NewsCategory
                {
                    Id= Guid.NewGuid(),
                    Category= "Journal"
                },
                new NewsCategory
                { 
                    Id = Guid.NewGuid(),
                    Category= "Product"
                },
                new NewsCategory
                {
                    Id =Guid.NewGuid(),
                    Category= "Event"
                },
                new NewsCategory
                {
                    Id = Guid.NewGuid(),
                    Category = "Member"
                }
                );
        }
    }
            
}
