﻿using Microsoft.EntityFrameworkCore;
using NewsApplicationBackend.Interfaces;
using NewsApplicationBackend.Shared;

namespace NewsApplicationBackend.Repositories
{
    public class NewsRepository<T> :INewsRepository<T> where T:class
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly DbSet<T> _dbSet;
        public NewsRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = _dbContext.Set<T>();
        }

        /// <summary>
        /// Get All News Data
        /// </summary>
        /// <returns></returns>
        public async Task<List<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }

        /// <summary>
        /// Get News By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<T> GetById(Guid id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity == null)
            {
                throw new Exception("No entity with given id found");
            }
            return entity;
        }

        /// <summary>
        /// Create new News 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task<bool> Add(T entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            await _dbSet.AddAsync(entity);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        /// <summary>
        /// Update news
        /// </summary>
        /// <param name="updateAction"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<bool> Update(Action<T> updateAction, Guid id)
        {
            var data = _dbSet.Find(id);

            if (data == null)
            {
                throw new Exception($"Entity with id : {id} not found");
            }
            else
            {
                updateAction(data);
                await _dbContext.SaveChangesAsync();

                return true;

            }
        }

        /// <summary>
        /// Delete news
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<bool> Delete(Guid id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity == null)
            {
                throw new Exception($"Entity with id: {id} not found");
            }
            _dbSet.Remove(entity);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
