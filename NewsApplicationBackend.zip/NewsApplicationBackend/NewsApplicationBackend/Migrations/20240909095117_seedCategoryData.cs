﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NewsApplicationBackend.Migrations
{
    /// <inheritdoc />
    public partial class seedCategoryData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "NewsCategories",
                columns: new[] { "Id", "Category" },
                values: new object[,]
                {
                    { new Guid("2dfc23b8-46f8-49ea-a63a-70f18dc4ffb9"), "Event" },
                    { new Guid("60eedc82-a086-4be7-8206-387b07687443"), "Member" },
                    { new Guid("aef7f0b6-af39-4c12-b6c4-3d0f286c9b33"), "Journal" },
                    { new Guid("f77c95d6-12dd-436d-9b32-0bf207e451db"), "Product" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("2dfc23b8-46f8-49ea-a63a-70f18dc4ffb9"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("60eedc82-a086-4be7-8206-387b07687443"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("aef7f0b6-af39-4c12-b6c4-3d0f286c9b33"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("f77c95d6-12dd-436d-9b32-0bf207e451db"));
        }
    }
}
