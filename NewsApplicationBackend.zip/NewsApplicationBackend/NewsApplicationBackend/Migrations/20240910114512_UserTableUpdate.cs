﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NewsApplicationBackend.Migrations
{
    /// <inheritdoc />
    public partial class UserTableUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("2dfc23b8-46f8-49ea-a63a-70f18dc4ffb9"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("60eedc82-a086-4be7-8206-387b07687443"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("aef7f0b6-af39-4c12-b6c4-3d0f286c9b33"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("f77c95d6-12dd-436d-9b32-0bf207e451db"));

            migrationBuilder.RenameColumn(
                name: "Username",
                table: "Users",
                newName: "Email");

            migrationBuilder.InsertData(
                table: "NewsCategories",
                columns: new[] { "Id", "Category" },
                values: new object[,]
                {
                    { new Guid("0435592e-4959-489c-9788-a3cbeb359cf7"), "Journal" },
                    { new Guid("270539f3-b7ed-438d-82d9-d24f5f21e479"), "Product" },
                    { new Guid("440a5b0e-2757-4b2e-87b9-c422097339ee"), "Member" },
                    { new Guid("e030dc1e-8587-4082-8b40-7fc4b1e4aea3"), "Event" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("0435592e-4959-489c-9788-a3cbeb359cf7"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("270539f3-b7ed-438d-82d9-d24f5f21e479"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("440a5b0e-2757-4b2e-87b9-c422097339ee"));

            migrationBuilder.DeleteData(
                table: "NewsCategories",
                keyColumn: "Id",
                keyValue: new Guid("e030dc1e-8587-4082-8b40-7fc4b1e4aea3"));

            migrationBuilder.RenameColumn(
                name: "Email",
                table: "Users",
                newName: "Username");

            migrationBuilder.InsertData(
                table: "NewsCategories",
                columns: new[] { "Id", "Category" },
                values: new object[,]
                {
                    { new Guid("2dfc23b8-46f8-49ea-a63a-70f18dc4ffb9"), "Event" },
                    { new Guid("60eedc82-a086-4be7-8206-387b07687443"), "Member" },
                    { new Guid("aef7f0b6-af39-4c12-b6c4-3d0f286c9b33"), "Journal" },
                    { new Guid("f77c95d6-12dd-436d-9b32-0bf207e451db"), "Product" }
                });
        }
    }
}
