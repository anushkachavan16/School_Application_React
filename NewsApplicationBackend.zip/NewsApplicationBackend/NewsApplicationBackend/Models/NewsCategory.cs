﻿using System.ComponentModel.DataAnnotations;

namespace NewsApplicationBackend.Models
{
    public class NewsCategory
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public string Category { get; set; }
    }
}
