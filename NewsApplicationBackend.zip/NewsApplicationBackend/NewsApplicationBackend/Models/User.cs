﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace NewsApplicationBackend.Models
{
    public class User
    {
        [Key]
        [Column("UserId")]
        public Guid Id { get; set; }
        [Required]
        public string Email { get; set; }  
        [Required]
        public string Password { get; set; }
        public string RefreshToken { get; set; }
        public DateTime RefreshTokenExpireTime { get; set; }
    }
}
