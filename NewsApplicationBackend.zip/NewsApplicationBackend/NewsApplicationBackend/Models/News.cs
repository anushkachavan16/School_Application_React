﻿using System.ComponentModel.DataAnnotations;

namespace NewsApplicationBackend.Models
{
    public class News
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        public string Category { get; set; }

        [Required]
        public DateTime PublishDate { get; set; }

        [Required]
        public string Status { get; set; }
    }
}
